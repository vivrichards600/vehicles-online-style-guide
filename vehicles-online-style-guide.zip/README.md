Vehicles online style guide
===========================

This web application displays common elements used for the Web frontend for [disposing vehicles online](https://github.com/dvla/vehicles-online) as well as the mark-up required to recreate the element using the [disposing vehicles online](https://github.com/dvla/vehicles-online) assets folder (styles/javascripts/images.


This style guide is not official and not complete. It is a hobby project to help me quickly prototype new services with the same look and feel of a government digital service.
